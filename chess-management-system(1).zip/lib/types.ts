export type UserRole = "admin" | "trainer" | "member"

export type MembershipStatus = "active" | "inactive" | "suspended"

export type PaymentStatus = "paid" | "pending" | "overdue"

export type PaymentType = "membership" | "tournament" | "other"

export type TournamentType = "swiss" | "round_robin" | "knockout"

export type TournamentStatus = "planned" | "ongoing" | "completed" | "cancelled"

export type GameResult = "1-0" | "0-1" | "0.5-0.5" | "ongoing" | "bye"

export type EventType = "training" | "tournament" | "meeting" | "other"

export type AttendanceStatus = "present" | "absent" | "excused"

export interface Profile {
  id: string
  email: string
  full_name: string
  role: UserRole
  created_at: string
  updated_at: string
}

export interface Member {
  id: string
  profile_id: string
  member_number: string
  phone?: string
  address?: string
  city?: string
  postal_code?: string
  birth_date?: string
  join_date: string
  elo_rating: number
  membership_status: MembershipStatus
  notes?: string
  created_at: string
  updated_at: string
}

export interface Payment {
  id: string
  member_id: string
  amount: number
  payment_date: string
  payment_type: PaymentType
  payment_method?: string
  year: number
  status: PaymentStatus
  notes?: string
  created_at: string
}

export interface Tournament {
  id: string
  name: string
  description?: string
  start_date: string
  end_date: string
  tournament_type: TournamentType
  rounds: number
  status: TournamentStatus
  created_by: string
  created_at: string
  updated_at: string
}

export interface TournamentParticipant {
  id: string
  tournament_id: string
  member_id: string
  starting_elo: number
  current_points: number
  rank?: number
  registered_at: string
}

export interface Game {
  id: string
  tournament_id: string
  round_number: number
  white_player_id: string
  black_player_id: string
  result: GameResult
  played_at?: string
  notes?: string
  created_at: string
  updated_at: string
}

export interface Event {
  id: string
  title: string
  description?: string
  event_type: EventType
  start_time: string
  end_time: string
  location?: string
  created_by: string
  created_at: string
  updated_at: string
}

export interface Attendance {
  id: string
  event_id: string
  member_id: string
  status: AttendanceStatus
  notes?: string
  recorded_at: string
}

export interface News {
  id: string
  title: string
  content: string
  author_id: string
  published: boolean
  published_at?: string
  created_at: string
  updated_at: string
}
