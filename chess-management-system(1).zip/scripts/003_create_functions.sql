-- Function to automatically create profile on user signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, role)
  VALUES (
    new.id,
    new.email,
    COALESCE(new.raw_user_meta_data->>'full_name', new.email),
    COALESCE(new.raw_user_meta_data->>'role', 'member')
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN new;
END;
$$;

-- Trigger to call handle_new_user on auth.users insert
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_members_updated_at BEFORE UPDATE ON public.members
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_tournaments_updated_at BEFORE UPDATE ON public.tournaments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_games_updated_at BEFORE UPDATE ON public.games
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_events_updated_at BEFORE UPDATE ON public.events
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_news_updated_at BEFORE UPDATE ON public.news
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Function to calculate tournament standings
CREATE OR REPLACE FUNCTION public.calculate_tournament_standings(tournament_uuid UUID)
RETURNS TABLE (
  participant_id UUID,
  member_id UUID,
  member_name TEXT,
  points DECIMAL,
  games_played INTEGER,
  wins INTEGER,
  draws INTEGER,
  losses INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    tp.id as participant_id,
    tp.member_id,
    p.full_name as member_name,
    tp.current_points as points,
    COUNT(g.id)::INTEGER as games_played,
    COUNT(CASE 
      WHEN (g.white_player_id = tp.member_id AND g.result = '1-0') OR 
           (g.black_player_id = tp.member_id AND g.result = '0-1') 
      THEN 1 
    END)::INTEGER as wins,
    COUNT(CASE WHEN g.result = '0.5-0.5' THEN 1 END)::INTEGER as draws,
    COUNT(CASE 
      WHEN (g.white_player_id = tp.member_id AND g.result = '0-1') OR 
           (g.black_player_id = tp.member_id AND g.result = '1-0') 
      THEN 1 
    END)::INTEGER as losses
  FROM public.tournament_participants tp
  JOIN public.members m ON tp.member_id = m.id
  JOIN public.profiles p ON m.profile_id = p.id
  LEFT JOIN public.games g ON 
    g.tournament_id = tp.tournament_id AND 
    (g.white_player_id = tp.member_id OR g.black_player_id = tp.member_id) AND
    g.result IN ('1-0', '0-1', '0.5-0.5')
  WHERE tp.tournament_id = tournament_uuid
  GROUP BY tp.id, tp.member_id, p.full_name, tp.current_points
  ORDER BY tp.current_points DESC, games_played DESC;
END;
$$ LANGUAGE plpgsql;
