-- Function to increment participant points safely
CREATE OR REPLACE FUNCTION increment_participant_points(
  p_tournament_id UUID,
  p_member_id UUID,
  p_points DECIMAL
)
RETURNS VOID AS $$
BEGIN
  UPDATE public.tournament_participants
  SET current_points = current_points + p_points
  WHERE tournament_id = p_tournament_id AND member_id = p_member_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
