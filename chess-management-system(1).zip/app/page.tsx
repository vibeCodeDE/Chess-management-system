import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Trophy, Calendar, Newspaper, Shield, BarChart3, Github, Code2 } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <span className="text-xl font-bold">♔</span>
            </div>
            <span className="text-xl font-bold text-foreground">Schach Manager</span>
            <span className="ml-2 inline-block rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-800 dark:bg-green-900 dark:text-green-200">
              Open Source
            </span>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/auth/login">
              <Button variant="ghost">Anmelden</Button>
            </Link>
            <Link href="/auth/sign-up">
              <Button>Registrieren</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 md:py-28">
        <div className="mx-auto max-w-3xl text-center">
          <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
            Vereinsverwaltung für <span className="text-primary">Schachvereine</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground">
            Das komplette, <span className="font-semibold text-foreground">kostenlose und Open Source</span>{" "}
            Management-System für Schachvereine bis 200 Mitglieder. Mitgliederverwaltung, Turnierplanung, ELO-Ratings
            und mehr - alles in einer Anwendung.
          </p>
          <div className="mt-4 flex justify-center gap-2">
            <span className="inline-block rounded-full bg-blue-100 px-3 py-1 text-xs font-semibold text-blue-800 dark:bg-blue-900 dark:text-blue-200">
              MIT License
            </span>
            <span className="inline-block rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-800 dark:bg-slate-800 dark:text-slate-200">
              Community Driven
            </span>
          </div>
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link href="/auth/sign-up">
              <Button size="lg" className="min-w-[200px]">
                Jetzt starten
              </Button>
            </Link>
            <Link href="/auth/login">
              <Button size="lg" variant="outline" className="min-w-[200px] bg-transparent">
                Anmelden
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="border-t border-border bg-muted/50 py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-3xl font-bold text-foreground">Alle Funktionen im Überblick</h2>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <Card className="border-border bg-card">
              <CardHeader>
                <Users className="h-10 w-10 text-primary" />
                <CardTitle className="mt-4 text-card-foreground">Mitgliederverwaltung</CardTitle>
                <CardDescription>
                  Verwalten Sie Mitgliederprofile, Kontaktdaten, ELO-Ratings und Beitragszahlungen an einem Ort.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <Trophy className="h-10 w-10 text-primary" />
                <CardTitle className="mt-4 text-card-foreground">Turnierverwaltung</CardTitle>
                <CardDescription>
                  Planen Sie Turniere, erstellen Sie Paarungen nach dem Schweizer System und erfassen Sie Ergebnisse.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <Calendar className="h-10 w-10 text-primary" />
                <CardTitle className="mt-4 text-card-foreground">Kalender & Termine</CardTitle>
                <CardDescription>
                  Behalten Sie Trainings, Turniere und Vereinsveranstaltungen im Überblick mit Anwesenheitslisten.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <Newspaper className="h-10 w-10 text-primary" />
                <CardTitle className="mt-4 text-card-foreground">News & Mitteilungen</CardTitle>
                <CardDescription>
                  Kommunizieren Sie wichtige Informationen und Neuigkeiten an alle Vereinsmitglieder.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <Shield className="h-10 w-10 text-primary" />
                <CardTitle className="mt-4 text-card-foreground">Rollenbasierte Rechte</CardTitle>
                <CardDescription>
                  Unterschiedliche Berechtigungen für Admins, Trainer und Mitglieder für sichere Datenverwaltung.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <BarChart3 className="h-10 w-10 text-primary" />
                <CardTitle className="mt-4 text-card-foreground">ELO-Rating System</CardTitle>
                <CardDescription>
                  Automatische Berechnung und Tracking der Spielstärke aller Vereinsmitglieder.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      <section className="border-t border-border py-20">
        <div className="container mx-auto px-4">
          <h2 className="mb-12 text-center text-3xl font-bold text-foreground">Open Source & Community</h2>
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="border-border bg-card">
              <CardHeader>
                <Code2 className="h-10 w-10 text-primary" />
                <CardTitle className="mt-4 text-card-foreground">Kostenlos & Open Source</CardTitle>
                <CardDescription>
                  Das gesamte Projekt ist unter der MIT-Lizenz verfügbar. Verwenden, modifizieren und verteilen Sie
                  frei.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <Github className="h-10 w-10 text-primary" />
                <CardTitle className="mt-4 text-card-foreground">Community Beiträge</CardTitle>
                <CardDescription>
                  Tragen Sie zum Projekt bei. Ihre Ideen und Verbesserungen machen das System besser für alle.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-border bg-card">
              <CardHeader>
                <Shield className="h-10 w-10 text-primary" />
                <CardTitle className="mt-4 text-card-foreground">Transparent & Sicher</CardTitle>
                <CardDescription>
                  Quellcode ist öffentlich einsehbar. Keine versteckten Kosten, keine Überraschungen.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <Card className="bg-primary text-primary-foreground">
          <CardContent className="py-12 text-center">
            <h2 className="text-3xl font-bold">Bereit für bessere Vereinsverwaltung?</h2>
            <p className="mx-auto mt-4 max-w-xl opacity-90">
              Starten Sie jetzt kostenlos und erleben Sie, wie einfach Vereinsverwaltung sein kann. Komplett Open Source
              und von der Community für die Community.
            </p>
            <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:justify-center">
              <Link href="/auth/sign-up">
                <Button size="lg" variant="secondary">
                  Kostenlos registrieren
                </Button>
              </Link>
              <a href="https://github.com/vibeCodeDE/Chess-management-system" target="_blank" rel="noopener noreferrer">
                <Button size="lg" variant="secondary" className="opacity-90">
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                </Button>
              </a>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-muted/30 py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-sm text-muted-foreground">
              © 2025 Schach Management System. Open Source unter MIT Lizenz.
            </p>
            <div className="flex gap-6 text-sm text-muted-foreground">
              <a href="https://github.com/vibeCodeDE/Chess-management-system" className="hover:text-foreground">
                GitHub
              </a>
              <a href="#" className="hover:text-foreground">
                Dokumentation
              </a>
              <a href="#" className="hover:text-foreground">
                Lizenz
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
