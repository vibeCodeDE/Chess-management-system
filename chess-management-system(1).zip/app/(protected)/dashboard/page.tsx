import { createClient } from "@/lib/supabase/server"
import { StatsCards } from "@/components/dashboard/stats-cards"
import { RecentActivity } from "@/components/dashboard/recent-activity"
import { UpcomingEvents } from "@/components/dashboard/upcoming-events"
import { TournamentOverview } from "@/components/dashboard/tournament-overview"

export default async function DashboardPage() {
  const supabase = await createClient()

  // Fetch stats with error handling for missing tables
  let memberCount = 0
  let tournamentCount = 0
  let eventCount = 0
  let newsCount = 0

  try {
    const [members, tournaments, events, news] = await Promise.all([
      supabase.from("members").select("*", { count: "exact", head: true }),
      supabase.from("tournaments").select("*", { count: "exact", head: true }),
      supabase.from("events").select("*", { count: "exact", head: true }),
      supabase.from("news").select("*", { count: "exact", head: true }),
    ])

    memberCount = members.count || 0
    tournamentCount = tournaments.count || 0
    eventCount = events.count || 0
    newsCount = news.count || 0
  } catch (e) {
    console.log("[v0] Could not fetch stats - tables may not exist yet")
  }

  let recentNews: any[] = []
  let upcomingEvents: any[] = []
  let activeTournaments: any[] = []

  try {
    const [newsResult, eventsResult, tournamentsResult] = await Promise.all([
      supabase
        .from("news")
        .select("*, profiles:author_id(full_name)")
        .eq("published", true)
        .order("published_at", { ascending: false })
        .limit(5),
      supabase
        .from("events")
        .select("*, profiles:created_by(full_name)")
        .gte("start_time", new Date().toISOString())
        .order("start_time", { ascending: true })
        .limit(5),
      supabase
        .from("tournaments")
        .select("*, profiles:created_by(full_name)")
        .in("status", ["planned", "ongoing"])
        .order("start_date", { ascending: true })
        .limit(3),
    ])

    recentNews = newsResult.data || []
    upcomingEvents = eventsResult.data || []
    activeTournaments = tournamentsResult.data || []
  } catch (e) {
    console.log("[v0] Could not fetch dashboard data - tables may not exist yet")
  }

  return (
    <div className="p-6 lg:p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Willkommen im Schach Management System</p>
      </div>

      <StatsCards
        memberCount={memberCount}
        tournamentCount={tournamentCount}
        eventCount={eventCount}
        newsCount={newsCount}
      />

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <RecentActivity news={recentNews} />
        <UpcomingEvents events={upcomingEvents} />
      </div>

      <div className="mt-6">
        <TournamentOverview tournaments={activeTournaments} />
      </div>
    </div>
  )
}
