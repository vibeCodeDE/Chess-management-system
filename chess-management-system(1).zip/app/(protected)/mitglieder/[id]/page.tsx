import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { MemberDetails } from "@/components/members/member-details"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default async function MemberDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  if (id === "neu") {
    redirect("/mitglieder/neu")
  }

  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
  if (!uuidRegex.test(id)) {
    redirect("/mitglieder")
  }

  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  const { data: member } = await supabase
    .from("members")
    .select(
      `
      *,
      profiles:profile_id (
        full_name,
        email,
        role
      ),
      payments (*)
    `,
    )
    .eq("id", id)
    .single()

  if (!member) {
    redirect("/mitglieder")
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/mitglieder">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold">{member.profiles?.full_name}</h1>
          <p className="text-muted-foreground">Mitgliedsnr. {member.member_number}</p>
        </div>
      </div>

      <MemberDetails member={member} userRole={profile?.role || "member"} />
    </div>
  )
}
