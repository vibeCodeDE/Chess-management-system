import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { MemberForm } from "@/components/members/member-form"

export default async function NewMemberPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (!profile || !["admin", "trainer"].includes(profile.role)) {
    redirect("/mitglieder")
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-3xl font-bold">Neues Mitglied</h1>
        <p className="text-muted-foreground">Fügen Sie ein neues Mitglied hinzu</p>
      </div>

      <MemberForm />
    </div>
  )
}
