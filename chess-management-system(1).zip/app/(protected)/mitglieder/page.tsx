import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { MembersTable } from "@/components/members/members-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function MembersPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const { data: members } = await supabase
    .from("members")
    .select(
      `
      *,
      profiles:profile_id (
        full_name,
        email,
        role
      )
    `,
    )
    .order("member_number", { ascending: true })

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Mitglieder</h1>
          <p className="text-muted-foreground">Verwalten Sie alle Vereinsmitglieder</p>
        </div>
        {profile?.role && ["admin", "trainer"].includes(profile.role) && (
          <Button asChild>
            <Link href="/mitglieder/neu">
              <Plus className="mr-2 h-4 w-4" />
              Neues Mitglied
            </Link>
          </Button>
        )}
      </div>

      <MembersTable members={members || []} userRole={profile?.role || "member"} />
    </div>
  )
}
