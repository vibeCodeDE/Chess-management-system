import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { CalendarView } from "@/components/calendar/calendar-view"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function CalendarPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const { data: events } = await supabase.from("events").select("*").order("start_time", { ascending: true })

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Kalender</h1>
          <p className="text-muted-foreground">Termine und Veranstaltungen</p>
        </div>
        {profile?.role && ["admin", "trainer"].includes(profile.role) && (
          <Button asChild>
            <Link href="/kalender/neu">
              <Plus className="mr-2 h-4 w-4" />
              Neuer Termin
            </Link>
          </Button>
        )}
      </div>

      <CalendarView events={events || []} userRole={profile?.role || "member"} />
    </div>
  )
}
