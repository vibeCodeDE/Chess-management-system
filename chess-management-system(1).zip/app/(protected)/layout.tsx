import type React from "react"
import { createClient } from "@/lib/supabase/server"
import { Navigation } from "@/components/layout/navigation"

export default async function ProtectedLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  // If somehow we got here without a user, show a loading state
  // (middleware should have redirected, but this is a fallback)
  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <p>Laden...</p>
      </div>
    )
  }

  // Try to get profile
  let profile = null
  const { data } = await supabase.from("profiles").select("*").eq("id", user.id).single()
  profile = data

  // Default profile if none exists
  if (!profile) {
    profile = {
      id: user.id,
      full_name: user.email?.split("@")[0] || "User",
      role: "member",
    }
  }

  return (
    <div className="flex min-h-screen">
      <Navigation user={user} profile={profile} />
      <main className="flex-1 lg:pl-64">{children}</main>
    </div>
  )
}
