import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { TournamentDetails } from "@/components/tournaments/tournament-details"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default async function TournamentDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  if (id === "neu") {
    redirect("/turniere/neu")
  }

  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
  if (!uuidRegex.test(id)) {
    redirect("/turniere")
  }

  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  const { data: tournament } = await supabase.from("tournaments").select("*").eq("id", id).single()

  if (!tournament) {
    redirect("/turniere")
  }

  const { data: participants } = await supabase
    .from("tournament_participants")
    .select(
      `
      *,
      members:member_id (
        id,
        member_number,
        elo_rating,
        profiles:profile_id (
          full_name
        )
      )
    `,
    )
    .eq("tournament_id", id)
    .order("ranking", { ascending: true })

  const { data: games } = await supabase
    .from("games")
    .select(
      `
      *,
      white_player:white_player_id (
        id,
        profiles:profile_id (
          full_name
        )
      ),
      black_player:black_player_id (
        id,
        profiles:profile_id (
          full_name
        )
      )
    `,
    )
    .eq("tournament_id", id)
    .order("round_number", { ascending: true })

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/turniere">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold">{tournament.name}</h1>
          <p className="text-muted-foreground">{tournament.tournament_type}</p>
        </div>
      </div>

      <TournamentDetails
        tournament={tournament}
        participants={participants || []}
        games={games || []}
        userRole={profile?.role || "member"}
      />
    </div>
  )
}
