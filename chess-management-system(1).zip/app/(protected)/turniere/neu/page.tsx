import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { TournamentForm } from "@/components/tournaments/tournament-form"

export default async function NewTournamentPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (!profile || !["admin", "trainer"].includes(profile.role)) {
    redirect("/turniere")
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-3xl font-bold">Neues Turnier</h1>
        <p className="text-muted-foreground">Erstellen Sie ein neues Turnier</p>
      </div>

      <TournamentForm />
    </div>
  )
}
