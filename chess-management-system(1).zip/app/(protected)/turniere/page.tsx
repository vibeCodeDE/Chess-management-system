import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { TournamentsGrid } from "@/components/tournaments/tournaments-grid"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default async function TournamentsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  const { data: tournaments } = await supabase.from("tournaments").select("*").order("start_date", { ascending: false })

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Turniere</h1>
          <p className="text-muted-foreground">Verwalten Sie alle Vereinsturniere</p>
        </div>
        {profile?.role && ["admin", "trainer"].includes(profile.role) && (
          <Button asChild>
            <Link href="/turniere/neu">
              <Plus className="mr-2 h-4 w-4" />
              Neues Turnier
            </Link>
          </Button>
        )}
      </div>

      <TournamentsGrid tournaments={tournaments || []} userRole={profile?.role || "member"} />
    </div>
  )
}
