import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { NewsGrid } from "@/components/news/news-grid"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default async function NewsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  // Fetch news articles
  const { data: allNews } = await supabase
    .from("news")
    .select(
      `
      *,
      profiles:author_id (
        full_name
      )
    `,
    )
    .order("created_at", { ascending: false })

  const published = allNews?.filter((n) => n.published) || []
  const drafts = allNews?.filter((n) => !n.published) || []

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">News & Mitteilungen</h1>
          <p className="text-muted-foreground">Aktuelle Informationen aus dem Verein</p>
        </div>
        {profile?.role && ["admin", "trainer"].includes(profile.role) && (
          <Button asChild>
            <Link href="/news/neu">
              <Plus className="mr-2 h-4 w-4" />
              Neue Mitteilung
            </Link>
          </Button>
        )}
      </div>

      {["admin", "trainer"].includes(profile?.role || "") ? (
        <Tabs defaultValue="published" className="w-full">
          <TabsList>
            <TabsTrigger value="published">Veröffentlicht ({published.length})</TabsTrigger>
            <TabsTrigger value="drafts">Entwürfe ({drafts.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="published" className="mt-6">
            <NewsGrid news={published} userRole={profile?.role || "member"} />
          </TabsContent>

          <TabsContent value="drafts" className="mt-6">
            <NewsGrid news={drafts} userRole={profile?.role || "member"} />
          </TabsContent>
        </Tabs>
      ) : (
        <NewsGrid news={published} userRole={profile?.role || "member"} />
      )}
    </div>
  )
}
