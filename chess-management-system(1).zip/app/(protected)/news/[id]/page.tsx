import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { NewsArticle } from "@/components/news/news-article"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default async function NewsDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params

  if (id === "neu") {
    redirect("/news/neu")
  }

  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i
  if (!uuidRegex.test(id)) {
    redirect("/news")
  }

  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  const { data: article } = await supabase
    .from("news")
    .select(
      `
      *,
      profiles:author_id (
        full_name
      )
    `,
    )
    .eq("id", id)
    .single()

  if (!article) {
    redirect("/news")
  }

  // Check if user can view unpublished articles
  if (!article.published && !["admin", "trainer"].includes(profile?.role || "")) {
    redirect("/news")
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/news">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
      </div>

      <NewsArticle article={article} userRole={profile?.role || "member"} />
    </div>
  )
}
