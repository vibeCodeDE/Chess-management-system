import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { NewsForm } from "@/components/news/news-form"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default async function EditNewsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (!profile || !["admin", "trainer"].includes(profile.role)) {
    redirect("/news")
  }

  const { data: article } = await supabase.from("news").select("*").eq("id", id).single()

  if (!article) {
    redirect("/news")
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" asChild>
          <Link href={`/news/${id}`}>
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-3xl font-bold">Mitteilung bearbeiten</h1>
          <p className="text-muted-foreground">{article.title}</p>
        </div>
      </div>

      <NewsForm article={article} />
    </div>
  )
}
