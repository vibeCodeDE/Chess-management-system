import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { NewsForm } from "@/components/news/news-form"

export default async function NewNewsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) {
    redirect("/auth/login")
  }

  const { data: profile } = await supabase.from("profiles").select("role").eq("id", user.id).single()

  if (!profile || !["admin", "trainer"].includes(profile.role)) {
    redirect("/news")
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-3xl font-bold">Neue Mitteilung</h1>
        <p className="text-muted-foreground">Erstellen Sie eine neue Mitteilung</p>
      </div>

      <NewsForm />
    </div>
  )
}
