"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import type { News } from "@/lib/types"

interface NewsFormProps {
  article?: News
}

export function NewsForm({ article }: NewsFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    title: article?.title || "",
    content: article?.content || "",
    published: article?.published || false,
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const supabase = createClient()

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Nicht angemeldet")

      if (article) {
        // Update existing article
        const updateData: {
          title: string
          content: string
          published: boolean
          published_at?: string | null
        } = {
          title: formData.title,
          content: formData.content,
          published: formData.published,
        }

        // Set published_at if publishing for the first time
        if (formData.published && !article.published) {
          updateData.published_at = new Date().toISOString()
        }

        const { error } = await supabase.from("news").update(updateData).eq("id", article.id)

        if (error) throw error

        router.push(`/news/${article.id}`)
      } else {
        // Create new article
        const { data, error } = await supabase
          .from("news")
          .insert({
            title: formData.title,
            content: formData.content,
            author_id: user.id,
            published: formData.published,
            published_at: formData.published ? new Date().toISOString() : null,
          })
          .select()
          .single()

        if (error) throw error

        router.push(`/news/${data.id}`)
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Ein Fehler ist aufgetreten")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <Card>
        <CardHeader>
          <CardTitle>Mitteilungsdetails</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Titel *</Label>
            <Input
              id="title"
              required
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Inhalt *</Label>
            <Textarea
              id="content"
              required
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              rows={12}
              placeholder="Schreiben Sie hier Ihre Mitteilung..."
            />
          </div>

          <div className="flex items-center justify-between rounded-lg border p-4">
            <div className="space-y-0.5">
              <Label htmlFor="published" className="text-base">
                Veröffentlichen
              </Label>
              <p className="text-sm text-muted-foreground">Die Mitteilung wird für alle Mitglieder sichtbar sein</p>
            </div>
            <Switch
              id="published"
              checked={formData.published}
              onCheckedChange={(checked) => setFormData({ ...formData, published: checked })}
            />
          </div>
        </CardContent>
      </Card>

      {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

      <div className="mt-6 flex gap-4">
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Wird gespeichert..." : article ? "Änderungen speichern" : "Mitteilung erstellen"}
        </Button>
        <Button type="button" variant="outline" onClick={() => router.back()}>
          Abbrechen
        </Button>
      </div>
    </form>
  )
}
