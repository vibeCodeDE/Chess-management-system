"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, User, Newspaper } from "lucide-react"
import Link from "next/link"
import type { News } from "@/lib/types"

interface NewsGridProps {
  news: (News & { profiles?: { full_name: string } })[]
  userRole: string
}

export function NewsGrid({ news, userRole }: NewsGridProps) {
  if (news.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Newspaper className="h-12 w-12 text-muted-foreground mb-4" />
        <p className="text-lg font-medium">Keine Mitteilungen gefunden</p>
        <p className="text-sm text-muted-foreground">Es gibt derzeit keine Mitteilungen</p>
      </div>
    )
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {news.map((article) => (
        <Card key={article.id} className="hover:shadow-lg transition-shadow flex flex-col">
          <CardHeader>
            <div className="flex items-start justify-between gap-2">
              <CardTitle className="text-xl line-clamp-2">{article.title}</CardTitle>
              {!article.published && <Badge variant="secondary">Entwurf</Badge>}
            </div>
            <CardDescription className="line-clamp-3">{article.content.substring(0, 150)}...</CardDescription>
          </CardHeader>
          <CardContent className="mt-auto space-y-4">
            <div className="flex flex-col gap-2 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span>{article.profiles?.full_name}</span>
              </div>

              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>
                  {article.published_at
                    ? new Date(article.published_at).toLocaleDateString("de-DE")
                    : new Date(article.created_at).toLocaleDateString("de-DE")}
                </span>
              </div>
            </div>

            <Button asChild className="w-full">
              <Link href={`/news/${article.id}`}>Weiterlesen</Link>
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
