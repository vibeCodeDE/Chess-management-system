"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { AddParticipantDialog } from "@/components/tournaments/add-participant-dialog"
import type { TournamentParticipant } from "@/lib/types"

interface ParticipantsTableProps {
  tournamentId: string
  participants: (TournamentParticipant & {
    members?: {
      id: string
      member_number: string
      elo_rating: number
      profiles?: { full_name: string }
    }
  })[]
  userRole: string
  tournamentStatus: string
}

export function ParticipantsTable({ tournamentId, participants, userRole, tournamentStatus }: ParticipantsTableProps) {
  const [showAddDialog, setShowAddDialog] = useState(false)

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Teilnehmer</CardTitle>
          {["admin", "trainer"].includes(userRole) && tournamentStatus !== "completed" && (
            <Button onClick={() => setShowAddDialog(true)} size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Teilnehmer hinzufügen
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {participants.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Keine Teilnehmer vorhanden</p>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Rang</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Mitgliedsnr.</TableHead>
                    <TableHead>Start-ELO</TableHead>
                    <TableHead className="text-right">Punkte</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {participants.map((participant, index) => (
                    <TableRow key={participant.id}>
                      <TableCell className="font-bold">{index + 1}</TableCell>
                      <TableCell>{participant.members?.profiles?.full_name}</TableCell>
                      <TableCell>{participant.members?.member_number}</TableCell>
                      <TableCell>{participant.starting_elo}</TableCell>
                      <TableCell className="text-right font-bold">{participant.current_points}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <AddParticipantDialog
        tournamentId={tournamentId}
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        existingParticipants={participants.map((p) => p.member_id)}
      />
    </>
  )
}
