"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Users, Trophy } from "lucide-react"
import Link from "next/link"
import type { Tournament } from "@/lib/types"

interface TournamentsGridProps {
  tournaments: (Tournament & { profiles?: { full_name: string } })[]
  userRole: string
}

export function TournamentsGrid({ tournaments, userRole }: TournamentsGridProps) {
  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
      planned: "secondary",
      ongoing: "default",
      completed: "outline",
      cancelled: "destructive",
    }
    const labels: Record<string, string> = {
      planned: "Geplant",
      ongoing: "Laufend",
      completed: "Abgeschlossen",
      cancelled: "Abgesagt",
    }
    return <Badge variant={variants[status] || "default"}>{labels[status] || status}</Badge>
  }

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      swiss: "Schweizer System",
      round_robin: "Rundenturnier",
      knockout: "K.O.-System",
    }
    return labels[type] || type
  }

  if (tournaments.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center">
        <Trophy className="h-12 w-12 text-muted-foreground mb-4" />
        <p className="text-lg font-medium">Keine Turniere gefunden</p>
        <p className="text-sm text-muted-foreground">Es gibt derzeit keine Turniere in dieser Kategorie</p>
      </div>
    )
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {tournaments.map((tournament) => (
        <Card key={tournament.id} className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <div className="flex items-start justify-between">
              <CardTitle className="text-xl">{tournament.name}</CardTitle>
              {getStatusBadge(tournament.status)}
            </div>
            <CardDescription>{tournament.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Calendar className="h-4 w-4" />
              <span>
                {new Date(tournament.start_date).toLocaleDateString("de-DE")} -{" "}
                {new Date(tournament.end_date).toLocaleDateString("de-DE")}
              </span>
            </div>

            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Trophy className="h-4 w-4" />
              <span>{getTypeLabel(tournament.tournament_type)}</span>
            </div>

            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Users className="h-4 w-4" />
              <span>{tournament.rounds} Runden</span>
            </div>

            <Button asChild className="w-full">
              <Link href={`/turniere/${tournament.id}`}>Details anzeigen</Link>
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
