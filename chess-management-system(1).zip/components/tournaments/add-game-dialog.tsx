"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface AddGameDialogProps {
  tournamentId: string
  open: boolean
  onOpenChange: (open: boolean) => void
  rounds: number
}

export function AddGameDialog({ tournamentId, open, onOpenChange, rounds }: AddGameDialogProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [participants, setParticipants] = useState<Array<{ id: string; full_name: string }>>([])
  const [formData, setFormData] = useState({
    round_number: "1",
    white_player_id: "",
    black_player_id: "",
  })

  useEffect(() => {
    if (open) {
      const fetchParticipants = async () => {
        const supabase = createClient()
        const { data } = await supabase
          .from("tournament_participants")
          .select(
            `
            member_id,
            members (
              id,
              profiles:profile_id (
                full_name
              )
            )
          `,
          )
          .eq("tournament_id", tournamentId)

        const formattedParticipants =
          data?.map(
            (p: {
              member_id: string
              members: { id: string; profiles: { full_name: string } | null } | null
            }) => ({
              id: p.member_id,
              full_name: p.members?.profiles?.full_name || "",
            }),
          ) || []

        setParticipants(formattedParticipants)
      }
      fetchParticipants()
    }
  }, [open, tournamentId])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const supabase = createClient()

    try {
      const { error } = await supabase.from("games").insert({
        tournament_id: tournamentId,
        round_number: Number.parseInt(formData.round_number),
        white_player_id: formData.white_player_id,
        black_player_id: formData.black_player_id,
        result: "ongoing",
      })

      if (error) throw error

      onOpenChange(false)
      setFormData({ round_number: "1", white_player_id: "", black_player_id: "" })
      router.refresh()
    } catch (error) {
      console.error("[v0] Error adding game:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Partie hinzufügen</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="round_number">Runde *</Label>
              <Select
                value={formData.round_number}
                onValueChange={(value) => setFormData({ ...formData, round_number: value })}
              >
                <SelectTrigger id="round_number">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Array.from({ length: rounds }, (_, i) => i + 1).map((round) => (
                    <SelectItem key={round} value={round.toString()}>
                      Runde {round}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="white_player">Spieler Weiß *</Label>
              <Select
                value={formData.white_player_id}
                onValueChange={(value) => setFormData({ ...formData, white_player_id: value })}
              >
                <SelectTrigger id="white_player">
                  <SelectValue placeholder="Spieler auswählen..." />
                </SelectTrigger>
                <SelectContent>
                  {participants
                    .filter((p) => p.id !== formData.black_player_id)
                    .map((participant) => (
                      <SelectItem key={participant.id} value={participant.id}>
                        {participant.full_name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="black_player">Spieler Schwarz *</Label>
              <Select
                value={formData.black_player_id}
                onValueChange={(value) => setFormData({ ...formData, black_player_id: value })}
              >
                <SelectTrigger id="black_player">
                  <SelectValue placeholder="Spieler auswählen..." />
                </SelectTrigger>
                <SelectContent>
                  {participants
                    .filter((p) => p.id !== formData.white_player_id)
                    .map((participant) => (
                      <SelectItem key={participant.id} value={participant.id}>
                        {participant.full_name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="mt-6">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={isLoading || !formData.white_player_id || !formData.black_player_id}>
              {isLoading ? "Wird hinzugefügt..." : "Hinzufügen"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
