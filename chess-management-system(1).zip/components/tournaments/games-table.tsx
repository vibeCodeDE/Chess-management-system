"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Plus } from "lucide-react"
import { AddGameDialog } from "@/components/tournaments/add-game-dialog"
import { UpdateGameResultDialog } from "@/components/tournaments/update-game-result-dialog"
import type { Game } from "@/lib/types"

interface GamesTableProps {
  tournamentId: string
  games: (Game & {
    white_player?: { id: string; profiles?: { full_name: string } }
    black_player?: { id: string; profiles?: { full_name: string } }
  })[]
  rounds: number
  userRole: string
  tournamentStatus: string
}

export function GamesTable({ tournamentId, games, rounds, userRole, tournamentStatus }: GamesTableProps) {
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [selectedGame, setSelectedGame] = useState<string | null>(null)

  const getResultBadge = (result: string) => {
    if (result === "ongoing") return <Badge variant="secondary">Laufend</Badge>
    if (result === "bye") return <Badge variant="outline">Freilos</Badge>
    return <Badge variant="default">{result}</Badge>
  }

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Partien</CardTitle>
          {["admin", "trainer"].includes(userRole) && tournamentStatus !== "completed" && (
            <Button onClick={() => setShowAddDialog(true)} size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Partie hinzufügen
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {games.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Keine Partien vorhanden</p>
          ) : (
            <div className="space-y-6">
              {Array.from({ length: rounds }, (_, i) => i + 1).map((round) => {
                const roundGames = games.filter((g) => g.round_number === round)
                if (roundGames.length === 0) return null

                return (
                  <div key={round}>
                    <h3 className="font-semibold mb-3">Runde {round}</h3>
                    <div className="rounded-md border">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Weiß</TableHead>
                            <TableHead className="text-center">vs</TableHead>
                            <TableHead>Schwarz</TableHead>
                            <TableHead>Ergebnis</TableHead>
                            {["admin", "trainer"].includes(userRole) && <TableHead>Aktion</TableHead>}
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {roundGames.map((game) => (
                            <TableRow key={game.id}>
                              <TableCell>{game.white_player?.profiles?.full_name}</TableCell>
                              <TableCell className="text-center text-muted-foreground">vs</TableCell>
                              <TableCell>{game.black_player?.profiles?.full_name}</TableCell>
                              <TableCell>{getResultBadge(game.result)}</TableCell>
                              {["admin", "trainer"].includes(userRole) && (
                                <TableCell>
                                  {game.result === "ongoing" && (
                                    <Button variant="ghost" size="sm" onClick={() => setSelectedGame(game.id)}>
                                      Ergebnis eintragen
                                    </Button>
                                  )}
                                </TableCell>
                              )}
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <AddGameDialog tournamentId={tournamentId} open={showAddDialog} onOpenChange={setShowAddDialog} rounds={rounds} />

      {selectedGame && (
        <UpdateGameResultDialog
          gameId={selectedGame}
          open={!!selectedGame}
          onOpenChange={() => setSelectedGame(null)}
        />
      )}
    </>
  )
}
