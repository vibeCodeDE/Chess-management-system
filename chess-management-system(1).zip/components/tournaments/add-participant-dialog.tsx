"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface AddParticipantDialogProps {
  tournamentId: string
  open: boolean
  onOpenChange: (open: boolean) => void
  existingParticipants: string[]
}

export function AddParticipantDialog({
  tournamentId,
  open,
  onOpenChange,
  existingParticipants,
}: AddParticipantDialogProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [members, setMembers] = useState<Array<{ id: string; full_name: string; elo_rating: number }>>([])
  const [selectedMember, setSelectedMember] = useState("")

  useEffect(() => {
    if (open) {
      const fetchMembers = async () => {
        const supabase = createClient()
        const { data } = await supabase
          .from("members")
          .select(
            `
            id,
            elo_rating,
            profiles:profile_id (
              full_name
            )
          `,
          )
          .eq("membership_status", "active")

        const formattedMembers =
          data
            ?.filter((m) => !existingParticipants.includes(m.id))
            .map((m: { id: string; elo_rating: number; profiles: { full_name: string } | null }) => ({
              id: m.id,
              full_name: m.profiles?.full_name || "",
              elo_rating: m.elo_rating,
            })) || []

        setMembers(formattedMembers)
      }
      fetchMembers()
    }
  }, [open, existingParticipants])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const supabase = createClient()

    try {
      const selectedMemberData = members.find((m) => m.id === selectedMember)
      if (!selectedMemberData) throw new Error("Mitglied nicht gefunden")

      const { error } = await supabase.from("tournament_participants").insert({
        tournament_id: tournamentId,
        member_id: selectedMember,
        starting_elo: selectedMemberData.elo_rating,
        current_points: 0,
      })

      if (error) throw error

      onOpenChange(false)
      router.refresh()
    } catch (error) {
      console.error("[v0] Error adding participant:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Teilnehmer hinzufügen</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="member">Mitglied auswählen *</Label>
              <Select value={selectedMember} onValueChange={setSelectedMember}>
                <SelectTrigger id="member">
                  <SelectValue placeholder="Mitglied auswählen..." />
                </SelectTrigger>
                <SelectContent>
                  {members.map((member) => (
                    <SelectItem key={member.id} value={member.id}>
                      {member.full_name} (ELO: {member.elo_rating})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="mt-6">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={isLoading || !selectedMember}>
              {isLoading ? "Wird hinzugefügt..." : "Hinzufügen"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
