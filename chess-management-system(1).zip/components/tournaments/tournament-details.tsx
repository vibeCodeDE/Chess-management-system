"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ParticipantsTable } from "@/components/tournaments/participants-table"
import { GamesTable } from "@/components/tournaments/games-table"
import { Calendar, Trophy, Users } from "lucide-react"
import type { Tournament, TournamentParticipant, Game } from "@/lib/types"

interface TournamentDetailsProps {
  tournament: Tournament & { profiles?: { full_name: string } }
  participants: (TournamentParticipant & {
    members?: {
      id: string
      member_number: string
      elo_rating: number
      profiles?: { full_name: string }
    }
  })[]
  games: (Game & {
    white_player?: { id: string; profiles?: { full_name: string } }
    black_player?: { id: string; profiles?: { full_name: string } }
  })[]
  userRole: string
}

export function TournamentDetails({ tournament, participants, games, userRole }: TournamentDetailsProps) {
  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
      planned: "secondary",
      ongoing: "default",
      completed: "outline",
      cancelled: "destructive",
    }
    const labels: Record<string, string> = {
      planned: "Geplant",
      ongoing: "Laufend",
      completed: "Abgeschlossen",
      cancelled: "Abgesagt",
    }
    return <Badge variant={variants[status] || "default"}>{labels[status] || status}</Badge>
  }

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      swiss: "Schweizer System",
      round_robin: "Rundenturnier",
      knockout: "K.O.-System",
    }
    return labels[type] || type
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium">Status</CardTitle>
          </CardHeader>
          <CardContent>{getStatusBadge(tournament.status)}</CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Zeitraum
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm">
              {new Date(tournament.start_date).toLocaleDateString("de-DE")} -{" "}
              {new Date(tournament.end_date).toLocaleDateString("de-DE")}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Trophy className="h-4 w-4" />
              System
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm">{getTypeLabel(tournament.tournament_type)}</p>
            <p className="text-xs text-muted-foreground">{tournament.rounds} Runden</p>
          </CardContent>
        </Card>
      </div>

      {tournament.description && (
        <Card>
          <CardHeader>
            <CardTitle>Beschreibung</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground whitespace-pre-wrap">{tournament.description}</p>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="standings" className="w-full">
        <TabsList>
          <TabsTrigger value="standings">
            <Users className="mr-2 h-4 w-4" />
            Rangliste ({participants.length})
          </TabsTrigger>
          <TabsTrigger value="games">
            <Trophy className="mr-2 h-4 w-4" />
            Partien ({games.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="standings" className="mt-6">
          <ParticipantsTable
            tournamentId={tournament.id}
            participants={participants}
            userRole={userRole}
            tournamentStatus={tournament.status}
          />
        </TabsContent>

        <TabsContent value="games" className="mt-6">
          <GamesTable
            tournamentId={tournament.id}
            games={games}
            rounds={tournament.rounds}
            userRole={userRole}
            tournamentStatus={tournament.status}
          />
        </TabsContent>
      </Tabs>
    </div>
  )
}
