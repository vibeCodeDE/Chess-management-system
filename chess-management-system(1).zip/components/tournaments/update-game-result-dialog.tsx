"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface UpdateGameResultDialogProps {
  gameId: string
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function UpdateGameResultDialog({ gameId, open, onOpenChange }: UpdateGameResultDialogProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<string>("1-0")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const supabase = createClient()

    try {
      // Update game result
      const { error: gameError, data: gameData } = await supabase
        .from("games")
        .update({
          result: result,
          played_at: new Date().toISOString(),
        })
        .eq("id", gameId)
        .select()
        .single()

      if (gameError) throw gameError

      // Update participant points
      const whitePoints = result === "1-0" ? 1 : result === "0.5-0.5" ? 0.5 : 0
      const blackPoints = result === "0-1" ? 1 : result === "0.5-0.5" ? 0.5 : 0

      const { error: whiteError } = await supabase.rpc("increment_participant_points", {
        p_tournament_id: gameData.tournament_id,
        p_member_id: gameData.white_player_id,
        p_points: whitePoints,
      })

      const { error: blackError } = await supabase.rpc("increment_participant_points", {
        p_tournament_id: gameData.tournament_id,
        p_member_id: gameData.black_player_id,
        p_points: blackPoints,
      })

      if (whiteError || blackError) {
        // Fallback: update directly
        await supabase
          .from("tournament_participants")
          .update({
            current_points: supabase.raw(`current_points + ${whitePoints}`),
          })
          .eq("tournament_id", gameData.tournament_id)
          .eq("member_id", gameData.white_player_id)

        await supabase
          .from("tournament_participants")
          .update({
            current_points: supabase.raw(`current_points + ${blackPoints}`),
          })
          .eq("tournament_id", gameData.tournament_id)
          .eq("member_id", gameData.black_player_id)
      }

      onOpenChange(false)
      router.refresh()
    } catch (error) {
      console.error("[v0] Error updating game result:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Ergebnis eintragen</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="result">Ergebnis *</Label>
              <Select value={result} onValueChange={setResult}>
                <SelectTrigger id="result">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1-0">1-0 (Weiß gewinnt)</SelectItem>
                  <SelectItem value="0.5-0.5">0.5-0.5 (Remis)</SelectItem>
                  <SelectItem value="0-1">0-1 (Schwarz gewinnt)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter className="mt-6">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Wird gespeichert..." : "Speichern"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
