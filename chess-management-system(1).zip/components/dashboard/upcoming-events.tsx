"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, MapPin, ArrowRight } from "lucide-react"
import Link from "next/link"
import type { Event } from "@/lib/types"

interface UpcomingEventsProps {
  events: (Event & { profiles?: { full_name: string } })[]
}

export function UpcomingEvents({ events }: UpcomingEventsProps) {
  const getEventTypeBadge = (type: string) => {
    const variants: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
      training: "default",
      tournament: "secondary",
      meeting: "outline",
      other: "outline",
    }
    const labels: Record<string, string> = {
      training: "Training",
      tournament: "Turnier",
      meeting: "Versammlung",
      other: "Sonstiges",
    }
    return <Badge variant={variants[type] || "default"}>{labels[type] || type}</Badge>
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Kommende Termine
        </CardTitle>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/kalender">
            Alle anzeigen
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent>
        {events.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">Keine kommenden Termine</p>
        ) : (
          <div className="space-y-4">
            {events.map((event) => (
              <Link key={event.id} href={`/kalender/${event.id}`}>
                <div className="space-y-2 p-3 rounded-lg border hover:bg-accent cursor-pointer">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="font-medium text-sm">{event.title}</h4>
                    {getEventTypeBadge(event.event_type)}
                  </div>

                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    <span>
                      {new Date(event.start_time).toLocaleDateString("de-DE", {
                        weekday: "short",
                        day: "numeric",
                        month: "short",
                      })}{" "}
                      um{" "}
                      {new Date(event.start_time).toLocaleTimeString("de-DE", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>

                  {event.location && (
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <MapPin className="h-3 w-3" />
                      <span>{event.location}</span>
                    </div>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
