"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, Trophy, Calendar, CreditCard } from "lucide-react"
import Link from "next/link"

interface StatsCardsProps {
  totalMembers: number
  totalTournaments: number
  upcomingEvents: number
  unpaidPayments: number
  userRole: string
}

export function StatsCards({
  totalMembers,
  totalTournaments,
  upcomingEvents,
  unpaidPayments,
  userRole,
}: StatsCardsProps) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Link href="/mitglieder">
        <Card className="hover:bg-accent transition-colors cursor-pointer">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aktive Mitglieder</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalMembers}</div>
            <p className="text-xs text-muted-foreground">Registrierte Mitglieder</p>
          </CardContent>
        </Card>
      </Link>

      <Link href="/turniere">
        <Card className="hover:bg-accent transition-colors cursor-pointer">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Aktive Turniere</CardTitle>
            <Trophy className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalTournaments}</div>
            <p className="text-xs text-muted-foreground">Geplant oder laufend</p>
          </CardContent>
        </Card>
      </Link>

      <Link href="/kalender">
        <Card className="hover:bg-accent transition-colors cursor-pointer">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Kommende Termine</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{upcomingEvents}</div>
            <p className="text-xs text-muted-foreground">In den nächsten Wochen</p>
          </CardContent>
        </Card>
      </Link>

      {["admin"].includes(userRole) && (
        <Card className="hover:bg-accent transition-colors">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Offene Zahlungen</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{unpaidPayments}</div>
            <p className="text-xs text-muted-foreground">Ausstehend oder überfällig</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
