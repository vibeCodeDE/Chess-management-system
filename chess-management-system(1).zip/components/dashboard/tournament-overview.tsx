"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Trophy, Calendar, ArrowRight } from "lucide-react"
import Link from "next/link"
import type { Tournament } from "@/lib/types"

interface TournamentOverviewProps {
  tournaments: (Tournament & { profiles?: { full_name: string } })[]
}

export function TournamentOverview({ tournaments }: TournamentOverviewProps) {
  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
      planned: "secondary",
      ongoing: "default",
      completed: "outline",
      cancelled: "destructive",
    }
    const labels: Record<string, string> = {
      planned: "Geplant",
      ongoing: "Laufend",
      completed: "Abgeschlossen",
      cancelled: "Abgesagt",
    }
    return <Badge variant={variants[status] || "default"}>{labels[status] || status}</Badge>
  }

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      swiss: "Schweizer System",
      round_robin: "Rundenturnier",
      knockout: "K.O.-System",
    }
    return labels[type] || type
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5" />
          Aktive Turniere
        </CardTitle>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/turniere">
            Alle anzeigen
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 md:grid-cols-3">
          {tournaments.map((tournament) => (
            <Link key={tournament.id} href={`/turniere/${tournament.id}`}>
              <div className="space-y-3 p-4 rounded-lg border hover:bg-accent cursor-pointer h-full">
                <div className="space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="font-medium text-sm line-clamp-1">{tournament.name}</h4>
                    {getStatusBadge(tournament.status)}
                  </div>
                  {tournament.description && (
                    <p className="text-xs text-muted-foreground line-clamp-2">{tournament.description}</p>
                  )}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    <span>
                      {new Date(tournament.start_date).toLocaleDateString("de-DE")} -{" "}
                      {new Date(tournament.end_date).toLocaleDateString("de-DE")}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Trophy className="h-3 w-3" />
                    <span>
                      {getTypeLabel(tournament.tournament_type)} • {tournament.rounds} Runden
                    </span>
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
