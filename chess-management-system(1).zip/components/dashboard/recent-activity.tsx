"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Newspaper, ArrowRight } from "lucide-react"
import Link from "next/link"
import type { News } from "@/lib/types"

interface RecentActivityProps {
  news: (News & { profiles?: { full_name: string } })[]
}

export function RecentActivity({ news }: RecentActivityProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Newspaper className="h-5 w-5" />
          Aktuelle Mitteilungen
        </CardTitle>
        <Button variant="ghost" size="sm" asChild>
          <Link href="/news">
            Alle anzeigen
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </CardHeader>
      <CardContent>
        {news.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">Keine aktuellen Mitteilungen</p>
        ) : (
          <div className="space-y-4">
            {news.map((article) => (
              <Link key={article.id} href={`/news/${article.id}`}>
                <div className="space-y-1 p-3 rounded-lg border hover:bg-accent cursor-pointer">
                  <h4 className="font-medium text-sm line-clamp-1">{article.title}</h4>
                  <p className="text-xs text-muted-foreground line-clamp-2">{article.content}</p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground pt-1">
                    <span>{article.profiles?.full_name}</span>
                    <span>•</span>
                    <span>
                      {article.published_at
                        ? new Date(article.published_at).toLocaleDateString("de-DE")
                        : new Date(article.created_at).toLocaleDateString("de-DE")}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
