"use client"

import { useState } from "react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Eye, Pencil, Search } from "lucide-react"
import Link from "next/link"
import type { Member } from "@/lib/types"

interface MembersTableProps {
  members: (Member & { profiles?: { full_name: string; email: string; role: string } })[]
  userRole: string
}

export function MembersTable({ members, userRole }: MembersTableProps) {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredMembers = members.filter(
    (member) =>
      member.profiles?.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.member_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.profiles?.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      active: "default",
      inactive: "secondary",
      suspended: "destructive",
    }
    const labels: Record<string, string> = {
      active: "Aktiv",
      inactive: "Inaktiv",
      suspended: "Gesperrt",
    }
    return <Badge variant={variants[status] || "default"}>{labels[status] || status}</Badge>
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Mitglied suchen..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Mitgliedsnr.</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>E-Mail</TableHead>
              <TableHead>ELO</TableHead>
              <TableHead>Beitrittsdatum</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Aktionen</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredMembers.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="text-center text-muted-foreground">
                  Keine Mitglieder gefunden
                </TableCell>
              </TableRow>
            ) : (
              filteredMembers.map((member) => (
                <TableRow key={member.id}>
                  <TableCell className="font-medium">{member.member_number}</TableCell>
                  <TableCell>{member.profiles?.full_name}</TableCell>
                  <TableCell>{member.profiles?.email}</TableCell>
                  <TableCell>{member.elo_rating}</TableCell>
                  <TableCell>{new Date(member.join_date).toLocaleDateString("de-DE")}</TableCell>
                  <TableCell>{getStatusBadge(member.membership_status)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/mitglieder/${member.id}`}>
                          <Eye className="h-4 w-4" />
                        </Link>
                      </Button>
                      {["admin", "trainer"].includes(userRole) && (
                        <Button variant="ghost" size="icon" asChild>
                          <Link href={`/mitglieder/${member.id}/bearbeiten`}>
                            <Pencil className="h-4 w-4" />
                          </Link>
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
