"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Plus } from "lucide-react"
import { AddPaymentDialog } from "@/components/members/add-payment-dialog"
import type { Payment } from "@/lib/types"

interface PaymentHistoryProps {
  memberId: string
  payments: Payment[]
  userRole: string
}

export function PaymentHistory({ memberId, payments, userRole }: PaymentHistoryProps) {
  const [showAddDialog, setShowAddDialog] = useState(false)

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      paid: "default",
      pending: "secondary",
      overdue: "destructive",
    }
    const labels: Record<string, string> = {
      paid: "Bezahlt",
      pending: "Ausstehend",
      overdue: "Überfällig",
    }
    return <Badge variant={variants[status] || "default"}>{labels[status] || status}</Badge>
  }

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      membership: "Mitgliedsbeitrag",
      tournament: "Turnier",
      other: "Sonstiges",
    }
    return labels[type] || type
  }

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Zahlungshistorie</CardTitle>
          {["admin"].includes(userRole) && (
            <Button onClick={() => setShowAddDialog(true)} size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Zahlung hinzufügen
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {payments.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Keine Zahlungen vorhanden</p>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Datum</TableHead>
                    <TableHead>Typ</TableHead>
                    <TableHead>Jahr</TableHead>
                    <TableHead>Betrag</TableHead>
                    <TableHead>Methode</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payments
                    .sort((a, b) => new Date(b.payment_date).getTime() - new Date(a.payment_date).getTime())
                    .map((payment) => (
                      <TableRow key={payment.id}>
                        <TableCell>{new Date(payment.payment_date).toLocaleDateString("de-DE")}</TableCell>
                        <TableCell>{getTypeLabel(payment.payment_type)}</TableCell>
                        <TableCell>{payment.year}</TableCell>
                        <TableCell className="font-medium">{payment.amount.toFixed(2)} €</TableCell>
                        <TableCell className="capitalize">{payment.payment_method || "-"}</TableCell>
                        <TableCell>{getStatusBadge(payment.status)}</TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <AddPaymentDialog memberId={memberId} open={showAddDialog} onOpenChange={setShowAddDialog} />
    </>
  )
}
