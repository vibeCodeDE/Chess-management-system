"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { Member } from "@/lib/types"

interface MemberFormProps {
  member?: Member & { profiles?: { full_name: string; email: string } }
}

export function MemberForm({ member }: MemberFormProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const [formData, setFormData] = useState({
    full_name: member?.profiles?.full_name || "",
    email: member?.profiles?.email || "",
    member_number: member?.member_number || "",
    phone: member?.phone || "",
    address: member?.address || "",
    city: member?.city || "",
    postal_code: member?.postal_code || "",
    birth_date: member?.birth_date || "",
    join_date: member?.join_date || new Date().toISOString().split("T")[0],
    elo_rating: member?.elo_rating?.toString() || "1200",
    membership_status: member?.membership_status || "active",
    notes: member?.notes || "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    const supabase = createClient()

    try {
      if (member) {
        // Update existing member
        const { error: memberError } = await supabase
          .from("members")
          .update({
            phone: formData.phone || null,
            address: formData.address || null,
            city: formData.city || null,
            postal_code: formData.postal_code || null,
            birth_date: formData.birth_date || null,
            join_date: formData.join_date,
            elo_rating: Number.parseInt(formData.elo_rating),
            membership_status: formData.membership_status,
            notes: formData.notes || null,
          })
          .eq("id", member.id)

        if (memberError) throw memberError

        router.push(`/mitglieder/${member.id}`)
      } else {
        // Create new profile and member
        const { data: authData, error: authError } = await supabase.auth.signUp({
          email: formData.email,
          password: Math.random().toString(36).slice(-12), // Generate temporary password
          options: {
            emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}/dashboard`,
            data: {
              full_name: formData.full_name,
              role: "member",
            },
          },
        })

        if (authError) throw authError
        if (!authData.user) throw new Error("Benutzer konnte nicht erstellt werden")

        // Wait a bit for the profile to be created by the trigger
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Create member record
        const { error: memberError } = await supabase.from("members").insert({
          profile_id: authData.user.id,
          member_number: formData.member_number,
          phone: formData.phone || null,
          address: formData.address || null,
          city: formData.city || null,
          postal_code: formData.postal_code || null,
          birth_date: formData.birth_date || null,
          join_date: formData.join_date,
          elo_rating: Number.parseInt(formData.elo_rating),
          membership_status: formData.membership_status,
          notes: formData.notes || null,
        })

        if (memberError) throw memberError

        router.push("/mitglieder")
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Ein Fehler ist aufgetreten")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Persönliche Daten</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="full_name">Vollständiger Name *</Label>
              <Input
                id="full_name"
                required
                disabled={!!member}
                value={formData.full_name}
                onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">E-Mail *</Label>
              <Input
                id="email"
                type="email"
                required
                disabled={!!member}
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Telefon</Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="birth_date">Geburtsdatum</Label>
              <Input
                id="birth_date"
                type="date"
                value={formData.birth_date}
                onChange={(e) => setFormData({ ...formData, birth_date: e.target.value })}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Adresse</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="address">Straße und Hausnummer</Label>
              <Input
                id="address"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="postal_code">PLZ</Label>
                <Input
                  id="postal_code"
                  value={formData.postal_code}
                  onChange={(e) => setFormData({ ...formData, postal_code: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="city">Stadt</Label>
                <Input
                  id="city"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Mitgliedschaft</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="member_number">Mitgliedsnummer *</Label>
              <Input
                id="member_number"
                required
                disabled={!!member}
                value={formData.member_number}
                onChange={(e) => setFormData({ ...formData, member_number: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="join_date">Beitrittsdatum *</Label>
              <Input
                id="join_date"
                type="date"
                required
                value={formData.join_date}
                onChange={(e) => setFormData({ ...formData, join_date: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="membership_status">Status *</Label>
              <Select
                value={formData.membership_status}
                onValueChange={(value) => setFormData({ ...formData, membership_status: value })}
              >
                <SelectTrigger id="membership_status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Aktiv</SelectItem>
                  <SelectItem value="inactive">Inaktiv</SelectItem>
                  <SelectItem value="suspended">Gesperrt</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Schach-Daten</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="elo_rating">ELO-Rating</Label>
              <Input
                id="elo_rating"
                type="number"
                value={formData.elo_rating}
                onChange={(e) => setFormData({ ...formData, elo_rating: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notizen</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={5}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {error && <p className="mt-4 text-sm text-destructive">{error}</p>}

      <div className="mt-6 flex gap-4">
        <Button type="submit" disabled={isLoading}>
          {isLoading ? "Wird gespeichert..." : member ? "Änderungen speichern" : "Mitglied erstellen"}
        </Button>
        <Button type="button" variant="outline" onClick={() => router.back()}>
          Abbrechen
        </Button>
      </div>
    </form>
  )
}
