"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Pencil, Mail, Phone, MapPin, Calendar, Trophy } from "lucide-react"
import Link from "next/link"
import type { Member, Payment } from "@/lib/types"
import { PaymentHistory } from "@/components/members/payment-history"

interface MemberDetailsProps {
  member: Member & {
    profiles?: { full_name: string; email: string; role: string }
    payments?: Payment[]
  }
  userRole: string
}

export function MemberDetails({ member, userRole }: MemberDetailsProps) {
  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      active: "default",
      inactive: "secondary",
      suspended: "destructive",
    }
    const labels: Record<string, string> = {
      active: "Aktiv",
      inactive: "Inaktiv",
      suspended: "Gesperrt",
    }
    return <Badge variant={variants[status] || "default"}>{labels[status] || status}</Badge>
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Persönliche Daten</CardTitle>
          {["admin", "trainer"].includes(userRole) && (
            <Button variant="ghost" size="icon" asChild>
              <Link href={`/mitglieder/${member.id}/bearbeiten`}>
                <Pencil className="h-4 w-4" />
              </Link>
            </Button>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3">
            <Mail className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">E-Mail</p>
              <p className="text-sm text-muted-foreground">{member.profiles?.email}</p>
            </div>
          </div>

          {member.phone && (
            <div className="flex items-center gap-3">
              <Phone className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Telefon</p>
                <p className="text-sm text-muted-foreground">{member.phone}</p>
              </div>
            </div>
          )}

          {(member.address || member.city) && (
            <div className="flex items-center gap-3">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Adresse</p>
                <p className="text-sm text-muted-foreground">
                  {member.address}
                  {member.address && <br />}
                  {member.postal_code} {member.city}
                </p>
              </div>
            </div>
          )}

          {member.birth_date && (
            <div className="flex items-center gap-3">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <div>
                <p className="text-sm font-medium">Geburtsdatum</p>
                <p className="text-sm text-muted-foreground">
                  {new Date(member.birth_date).toLocaleDateString("de-DE")}
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Mitgliedschaft</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm font-medium">Mitgliedsnummer</p>
            <p className="text-lg font-bold">{member.member_number}</p>
          </div>

          <div>
            <p className="text-sm font-medium">Status</p>
            <div className="mt-1">{getStatusBadge(member.membership_status)}</div>
          </div>

          <div>
            <p className="text-sm font-medium">Beitrittsdatum</p>
            <p className="text-sm text-muted-foreground">{new Date(member.join_date).toLocaleDateString("de-DE")}</p>
          </div>

          <div className="flex items-center gap-3">
            <Trophy className="h-4 w-4 text-muted-foreground" />
            <div>
              <p className="text-sm font-medium">ELO-Rating</p>
              <p className="text-lg font-bold">{member.elo_rating}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {member.notes && (
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Notizen</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground whitespace-pre-wrap">{member.notes}</p>
          </CardContent>
        </Card>
      )}

      <div className="md:col-span-2">
        <PaymentHistory memberId={member.id} payments={member.payments || []} userRole={userRole} />
      </div>
    </div>
  )
}
