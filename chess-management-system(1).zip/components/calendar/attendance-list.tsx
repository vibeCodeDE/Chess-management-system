"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { AddAttendanceDialog } from "@/components/calendar/add-attendance-dialog"
import type { Attendance } from "@/lib/types"

interface AttendanceListProps {
  eventId: string
  attendance: (Attendance & {
    members?: {
      id: string
      member_number: string
      profiles?: { full_name: string }
    }
  })[]
  userRole: string
}

export function AttendanceList({ eventId, attendance, userRole }: AttendanceListProps) {
  const [showAddDialog, setShowAddDialog] = useState(false)

  const getStatusBadge = (status: string) => {
    const variants: Record<string, "default" | "secondary" | "destructive"> = {
      present: "default",
      absent: "destructive",
      excused: "secondary",
    }
    const labels: Record<string, string> = {
      present: "Anwesend",
      absent: "Abwesend",
      excused: "Entschuldigt",
    }
    return <Badge variant={variants[status] || "default"}>{labels[status] || status}</Badge>
  }

  return (
    <>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Anwesenheitsliste</CardTitle>
          {["admin", "trainer"].includes(userRole) && (
            <Button onClick={() => setShowAddDialog(true)} size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Anwesenheit erfassen
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {attendance.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Keine Anwesenheiten erfasst</p>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Mitgliedsnr.</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Notizen</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attendance.map((record) => (
                    <TableRow key={record.id}>
                      <TableCell>{record.members?.profiles?.full_name}</TableCell>
                      <TableCell>{record.members?.member_number}</TableCell>
                      <TableCell>{getStatusBadge(record.status)}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{record.notes || "-"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {attendance.length > 0 && (
            <div className="mt-4 flex gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Badge variant="default">Anwesend</Badge>
                <span className="text-muted-foreground">{attendance.filter((a) => a.status === "present").length}</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="destructive">Abwesend</Badge>
                <span className="text-muted-foreground">{attendance.filter((a) => a.status === "absent").length}</span>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary">Entschuldigt</Badge>
                <span className="text-muted-foreground">{attendance.filter((a) => a.status === "excused").length}</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <AddAttendanceDialog
        eventId={eventId}
        open={showAddDialog}
        onOpenChange={setShowAddDialog}
        existingAttendance={attendance.map((a) => a.member_id)}
      />
    </>
  )
}
