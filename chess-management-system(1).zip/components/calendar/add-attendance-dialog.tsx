"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

interface AddAttendanceDialogProps {
  eventId: string
  open: boolean
  onOpenChange: (open: boolean) => void
  existingAttendance: string[]
}

export function AddAttendanceDialog({ eventId, open, onOpenChange, existingAttendance }: AddAttendanceDialogProps) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [members, setMembers] = useState<Array<{ id: string; full_name: string; member_number: string }>>([])
  const [formData, setFormData] = useState({
    member_id: "",
    status: "present",
    notes: "",
  })

  useEffect(() => {
    if (open) {
      const fetchMembers = async () => {
        const supabase = createClient()
        const { data } = await supabase
          .from("members")
          .select(
            `
            id,
            member_number,
            profiles:profile_id (
              full_name
            )
          `,
          )
          .eq("membership_status", "active")

        const formattedMembers =
          data
            ?.filter((m) => !existingAttendance.includes(m.id))
            .map((m: { id: string; member_number: string; profiles: { full_name: string } | null }) => ({
              id: m.id,
              full_name: m.profiles?.full_name || "",
              member_number: m.member_number,
            })) || []

        setMembers(formattedMembers)
      }
      fetchMembers()
    }
  }, [open, existingAttendance])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    const supabase = createClient()

    try {
      const { error } = await supabase.from("attendance").insert({
        event_id: eventId,
        member_id: formData.member_id,
        status: formData.status,
        notes: formData.notes || null,
      })

      if (error) throw error

      onOpenChange(false)
      setFormData({ member_id: "", status: "present", notes: "" })
      router.refresh()
    } catch (error) {
      console.error("[v0] Error adding attendance:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Anwesenheit erfassen</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="member">Mitglied auswählen *</Label>
              <Select
                value={formData.member_id}
                onValueChange={(value) => setFormData({ ...formData, member_id: value })}
              >
                <SelectTrigger id="member">
                  <SelectValue placeholder="Mitglied auswählen..." />
                </SelectTrigger>
                <SelectContent>
                  {members.map((member) => (
                    <SelectItem key={member.id} value={member.id}>
                      {member.full_name} ({member.member_number})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status *</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value })}>
                <SelectTrigger id="status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="present">Anwesend</SelectItem>
                  <SelectItem value="absent">Abwesend</SelectItem>
                  <SelectItem value="excused">Entschuldigt</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Notizen</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                rows={3}
              />
            </div>
          </div>

          <DialogFooter className="mt-6">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Abbrechen
            </Button>
            <Button type="submit" disabled={isLoading || !formData.member_id}>
              {isLoading ? "Wird gespeichert..." : "Speichern"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
