"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock, MapPin, User, Calendar } from "lucide-react"
import type { Event, Attendance } from "@/lib/types"
import { AttendanceList } from "@/components/calendar/attendance-list"

interface EventDetailsProps {
  event: Event & { profiles?: { full_name: string } }
  attendance: (Attendance & {
    members?: {
      id: string
      member_number: string
      profiles?: { full_name: string }
    }
  })[]
  userRole: string
}

export function EventDetails({ event, attendance, userRole }: EventDetailsProps) {
  const getEventTypeBadge = (type: string) => {
    const variants: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
      training: "default",
      tournament: "secondary",
      meeting: "outline",
      other: "outline",
    }
    const labels: Record<string, string> = {
      training: "Training",
      tournament: "Turnier",
      meeting: "Versammlung",
      other: "Sonstiges",
    }
    return <Badge variant={variants[type] || "default"}>{labels[type] || type}</Badge>
  }

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString)
    return {
      date: date.toLocaleDateString("de-DE", { weekday: "long", year: "numeric", month: "long", day: "numeric" }),
      time: date.toLocaleTimeString("de-DE", { hour: "2-digit", minute: "2-digit" }),
    }
  }

  const startDateTime = formatDateTime(event.start_time)
  const endDateTime = formatDateTime(event.end_time)

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Termindetails</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm font-medium mb-1">Typ</p>
            {getEventTypeBadge(event.event_type)}
          </div>

          <div className="flex items-start gap-3">
            <Calendar className="h-4 w-4 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm font-medium">Start</p>
              <p className="text-sm text-muted-foreground">{startDateTime.date}</p>
              <p className="text-sm text-muted-foreground">{startDateTime.time} Uhr</p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Clock className="h-4 w-4 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm font-medium">Ende</p>
              <p className="text-sm text-muted-foreground">{endDateTime.date}</p>
              <p className="text-sm text-muted-foreground">{endDateTime.time} Uhr</p>
            </div>
          </div>

          {event.location && (
            <div className="flex items-start gap-3">
              <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
              <div>
                <p className="text-sm font-medium">Ort</p>
                <p className="text-sm text-muted-foreground">{event.location}</p>
              </div>
            </div>
          )}

          <div className="flex items-start gap-3">
            <User className="h-4 w-4 text-muted-foreground mt-0.5" />
            <div>
              <p className="text-sm font-medium">Erstellt von</p>
              <p className="text-sm text-muted-foreground">{event.profiles?.full_name}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {event.description && (
        <Card>
          <CardHeader>
            <CardTitle>Beschreibung</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground whitespace-pre-wrap">{event.description}</p>
          </CardContent>
        </Card>
      )}

      <div className="md:col-span-2">
        <AttendanceList eventId={event.id} attendance={attendance} userRole={userRole} />
      </div>
    </div>
  )
}
