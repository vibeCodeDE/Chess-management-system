# Schach Management System

Ein modernes, kostenloses und **Open Source** Management-System für Schachvereine bis 200 Mitglieder.

**Live:** [schach.space](https://schach.space)  
**GitHub:** [vibeCodeDE/Chess-management-system](https://github.com/vibeCodeDE/Chess-management-system)

## 🎯 Features

### Mitgliederverwaltung
- Vollständige Mitgliederprofile mit Kontaktdaten
- ELO-Rating System mit automatischer Berechnung
- Beitragsverwaltung und Zahlungshistorie
- Mitglieder-Verzeichnis und Suche

### Turnierverwaltung
- Turnierplanung und -verwaltung
- Automatisches Paarungssystem (Schweizer System)
- Ergebniseingabe und Punkte-Berechnung
- Automatische Ranglisten-Updates

### Kalender & Termine
- Übersichtlicher Veranstaltungskalender
- Termine für Trainings, Turniere und Events
- Anwesenheitslisten und Tracking
- Unterschiedliche Event-Typen

### News & Kommunikation
- Vereinsmitteilungen und Ankündigungen
- Veröffentlichungs-Management
- News-Archive und Suche

### Admin & Sicherheit
- Rollenbasierte Zugriffskontrolle (Admin, Trainer, Mitglied)
- Row-Level Security (RLS) für alle Daten
- Sichere Authentifizierung mit Supabase
- Dashboard mit Vereins-Statistiken

## 🚀 Schnellstart

### Installation

1. **Repository klonen:**
```bash
git clone https://github.com/vibeCodeDE/Chess-management-system.git
cd Chess-management-system
```

2. **Dependencies installieren:**
```bash
bun install
# oder
npm install
```

3. **Umgebungsvariablen konfigurieren:**

Erstellen Sie eine `.env.local` Datei mit Ihren Supabase-Credentials:

```env
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

4. **Datenbank-Setup:**

Führen Sie die SQL-Scripts aus `scripts/` in Ihrer Supabase-Datenbank aus:

```bash
# 001_create_schema.sql
# 002_enable_rls.sql
# 003_create_functions.sql
```

5. **Entwicklungsserver starten:**
```bash
bun run dev
# oder
npm run dev
```

Öffnen Sie [http://localhost:3000](http://localhost:3000) im Browser.

## 📋 Systemanforderungen

- **Node.js** 18+ oder **Bun** 1.0+
- **Supabase** Account (kostenlos auf [supabase.com](https://supabase.com))
- **PostgreSQL** Datenbank (über Supabase)

## 🏗️ Technologie-Stack

- **Frontend:** Next.js 16, React 19, TypeScript
- **Styling:** Tailwind CSS, shadcn/ui
- **Datenbank:** PostgreSQL via Supabase
- **Auth:** Supabase Auth
- **Deployment:** Vercel

## 📖 Dokumentation

Weitere Informationen finden Sie in:

- [Benutzerdokumentation](./docs/USAGE.md)
- [Entwickler-Guide](./docs/DEVELOPMENT.md)
- [API-Referenz](./docs/API.md)

## 🤝 Beitragen

Wir freuen uns über Beiträge! So können Sie helfen:

1. **Bug melden:** Erstellen Sie ein Issue auf GitHub
2. **Feature-Vorschlag:** Diskutieren Sie neue Features im Discussions-Tab
3. **Code beitragen:** Erstellen Sie einen Pull Request

### Beitrags-Richtlinien

- Forken Sie das Repository
- Erstellen Sie einen Feature-Branch (`git checkout -b feature/AmazingFeature`)
- Committen Sie Ihre Änderungen (`git commit -m 'Add AmazingFeature'`)
- Pushen Sie zum Branch (`git push origin feature/AmazingFeature`)
- Öffnen Sie einen Pull Request

## 📄 Lizenz

Dieses Projekt ist unter der **MIT-Lizenz** lizenziert – siehe [LICENSE](./LICENSE) Datei für Details.

## 🙏 Danksagungen

- **Supabase** für die großartige Datenbank-Infrastruktur
- **Next.js** und **React** Communities
- **shadcn/ui** für die UI-Komponenten
- Alle Contributor und Vereins-Manager, die ihre Zeit beitragen

## 📞 Support & Community

- **GitHub Issues:** [Bug-Reports und Feature-Requests](https://github.com/vibeCodeDE/Chess-management-system/issues)
- **Discussions:** [Fragen und Diskussionen](https://github.com/vibeCodeDE/Chess-management-system/discussions)
- **Website:** [schach.space](https://schach.space)

## 🔗 Links

- [GitHub Repository](https://github.com/vibeCodeDE/Chess-management-system)
- [Live Demo](https://schach.space)
- [MIT Lizenz](./LICENSE)

---

**Gemacht mit ❤️ für die Schach-Community**
